package com.example.ai

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageView.setOnClickListener {
            // 创建一个Intent来启动ArticleActivity
            val intent = Intent(this, ArticleActivity::class.java)
            // 传递文章内容
            intent.putExtra("ARTICLE_CONTENT", "这是文章的内容。点击图片后显示的详细文章内容。")
            startActivity(intent)
        }
    }
}